<div class="nav_menu">
          <nav class="" role="navigation">
            <div class="nav toggle">
              <a id="menu_toggle"><i class="fa fa-bars"></i></a>
            </div>
            <ul class="nav navbar-nav navbar-right">
           
                  <li><a href="admin-logout.php"><i class="fa fa-sign-out pull-right"></i> Log Out</a>

            </ul>
          </nav>
        </div>