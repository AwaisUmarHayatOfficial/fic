<?php
$db = mysql_connect('localhost','ficgoppk_admin','_2=M^d~CypI?');
mysql_select_db('ficgoppk_new_fic',$db);
ob_start();
?>

