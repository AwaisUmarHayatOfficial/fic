<?php

$sfi = 'File too large. File must be less than 10 MB.'; 

$efi = 'Invalid file type. Only PDF, DOC, ZIP, DOCX, TxT, JPG, GIF and PNG types are accepted.'; 

$pefi = 'Invalid file type. Only  JPG, JPEG, GIF and PNG types are accepted.';

?>